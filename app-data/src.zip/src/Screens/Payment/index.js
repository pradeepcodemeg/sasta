//import liraries
import React, { Component } from 'react';
import { View, Text, StyleSheet,ScrollView,Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';


const Payment = ({ navigation,route }) => {
    return (
        <View >
            <Text style={{color: 'blue',fontWeight: 'bold',fontSize: 30,}}>Payment</Text>
        </View>
    );
};



export default Payment;