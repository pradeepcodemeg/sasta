export const SET_CART_DATA = 'SET_CART_DATA';

