export const API_URL = 'https://aliveztechnosoft.com/python-automations/GroceryApp/';
export const GOOGLE_MAP_API = 'AIzaSyB7qa8Uk4xxkHnrV6mGUCJrte7g9WH_hPA';