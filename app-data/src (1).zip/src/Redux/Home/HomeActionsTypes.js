export const SET_HOME_DATA = 'SET_HOME_DATA';

